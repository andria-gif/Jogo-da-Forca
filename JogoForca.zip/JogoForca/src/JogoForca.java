/**
 * Trabalho feito por Ândria Rosa Dias, Gabriel Jordani, Pedro Maciel e Roger Ramos
 */

import java.util.Scanner;

public class JogoForca {
    public static void main(String[] args) {
        String palavraChave;
        String letrasUsadas = "";
        String palavraAdivinhada = "";
        int erros = 0;

        Scanner teclado = new Scanner(System.in);

        System.out.print("Palavra secreta: ");
        palavraChave = teclado.nextLine();

        for (int i = 0; i < 100; i++) {
            System.out.println("");
        }

        System.out.println("Jogo da Forca! Adivinhe a palavra secreta, se você errar 6 vezes, você perde!");
        System.out.printf("A palavra possui %s letras!%n", palavraChave.length());

        for (int i = 0; i < palavraChave.length(); i++) {
            palavraAdivinhada += "_";

            for (int tentativas = 0; erros < 6; tentativas++) {

                System.out.printf("Rodada %d. Até agora você adivinhou: %s. Qual a sua próxima letra? ", tentativas + 1, palavraAdivinhada);

                char letraTentada = teclado.next().charAt(0);
                if (letrasUsadas.indexOf(letraTentada) >= 0) {
                    System.out.printf("Você já tentou a letra %c.%n", letraTentada);
                } else {
                    letrasUsadas += letraTentada;

                    if (palavraChave.indexOf(letraTentada) >= 0) {
                        palavraAdivinhada = "";

                        for (int j = 0; j < palavraChave.length(); j++) {
                            palavraAdivinhada += letrasUsadas.indexOf(palavraChave.charAt(j)) >= 0 ? palavraChave.charAt(j) : "_";
                        }

                        if (palavraAdivinhada.contains("_")) {
                            System.out.printf("A letra '%s' existe na palavra. Ainda tem letras escondidas%n", letraTentada);
                        } else {
                            System.out.printf("Parabéns! A palavra era '%s'. Você ganhou!", palavraAdivinhada);
                            System.exit(0);
                        }
                    } else {
                        System.out.printf("A letra %c não existe na palavra.%n", letraTentada);
                        erros++;
                        if (erros == 1) {
                            System.out.printf("Você errou %s vez%n%n", erros);
                        } else {
                            System.out.printf("Você errou %s vezes%n%n", erros);
                        }
                    }
                }
            }
        }
        System.out.printf("Você perdeu! A palavra era '%s'%n", palavraChave);
    }
}